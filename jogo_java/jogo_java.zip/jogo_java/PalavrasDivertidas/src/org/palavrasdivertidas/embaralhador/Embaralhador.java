package org.palavrasdivertidas.embaralhador;

public interface Embaralhador {
	public String embaralhar(String palavra);

}
